//
// Author: Christian Schulz <christian.schulz.phone@gmail.com>
// 

#include "area_bfs.h"

std::vector<int> area_bfs::m_deepth;
int area_bfs::round = 0;

area_bfs::area_bfs() {
                
}

area_bfs::~area_bfs() {
                
}

