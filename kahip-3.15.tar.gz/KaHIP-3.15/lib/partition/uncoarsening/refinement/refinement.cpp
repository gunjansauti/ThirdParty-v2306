/******************************************************************************
 * refinement.cpp 
 * *
 * Source of KaHIP -- Karlsruhe High Quality Partitioning.
 * Christian Schulz <christian.schulz.phone@gmail.com>
 *****************************************************************************/

#include "refinement.h"

refinement::refinement() {
                
}

refinement::~refinement() {
                
}



