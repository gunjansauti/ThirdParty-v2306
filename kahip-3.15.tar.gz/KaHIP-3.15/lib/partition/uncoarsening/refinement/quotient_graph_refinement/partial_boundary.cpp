/******************************************************************************
 * partial_boundary.cpp 
 * *
 * Source of KaHIP -- Karlsruhe High Quality Partitioning.
 * Christian Schulz <christian.schulz.phone@gmail.com>
 *****************************************************************************/

#include "partial_boundary.h"

PartialBoundary::PartialBoundary() {
                
}

PartialBoundary::~PartialBoundary() {
                
}

