/******************************************************************************
 * construct_distance_matrix.cpp
 * *
 * Source of KaHIP -- Karlsruhe High Quality Partitioning.
 * Christian Schulz <christian.schulz.phone@gmail.com>
 *****************************************************************************/


#include "construct_distance_matrix.h"

construct_distance_matrix::construct_distance_matrix() {
                
}

construct_distance_matrix::~construct_distance_matrix() {
                
}

